# PSP Flow – CRM & Customer Success Intelligence Platform

A GitHub-ready portfolio project by **Raihan Farhad Sakil** demonstrating CRM system design, revenue operations analytics, customer-success operations, workflow automation, and AI-assisted account intelligence for a synthetic B2B logistics-automation business context.

> Important: all customer, revenue, usage, and support data in the public demo is synthetic and generated with a fixed random seed. A clearly labelled synthetic HubSpot test scenario was verified in a real portal. This project does not claim real PSP Flow customers, production revenue, or production CRM deployment.

## Business problem

A growing logistics-automation SaaS team needs one reliable view of leads, deals, onboarding progress, product usage, support issues, renewals, and customer health. Sales needs pipeline visibility; Customer Success needs at-risk account alerts; management needs clear KPIs and documented CRM processes.

## Solution

This project implements a local CRM intelligence platform:

1. Synthetic B2B CRM dataset with realistic data-quality issues.
2. Normalized SQLite CRM database with relationships and constraints.
3. Data-quality checks for duplicates, missing fields, invalid stages, orphan records, and invalid dates.
4. Revenue Operations KPIs: funnel, win rate, weighted pipeline, response time, MRR, ARR, GRR, NRR, renewals.
5. Customer Success health score: usage, onboarding, support, and renewal timing.
6. Workflow automations: lead routing, onboarding creation, and at-risk alert tasks.
7. Rule-based account briefings grounded only in CRM data.
8. Streamlit interface for reviewer demo.
9. HubSpot read-only snapshot connector and verified synthetic portal scenario.

## Architecture

```text
Synthetic source data
        ↓
Raw CSV with deliberate quality issues
        ↓
Cleaning/validation reports
        ↓
Normalized SQLite CRM database
        ↓
Analytics model + customer health score
        ↓
Streamlit app + Power BI-ready exports
        ↓
Automation logs + account briefing
```

## CRM objects

The model includes companies, contacts, leads, deals, activities, owners, products/plans, subscriptions, onboarding, tasks, product-usage events, support tickets, customer-success activities, and automation logs.

Sales lifecycle:

```text
New Lead → Qualified → Demo → Proposal → Negotiation → Won/Lost
```

Customer lifecycle:

```text
Won → Onboarding → Active → At Risk → Renewal / Expansion / Churn
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/build_demo.py
streamlit run app.py
```

Run tests:

```bash
pytest -q
```

## Repository structure

```text
app.py                         Streamlit reviewer interface
scripts/build_demo.py           Rebuilds synthetic data, database, reports, KPIs, workflows
src/psp_crm/                    Core Python package
sql_schema.sql                  SQLite schema with constraints
contracts.md                    CRM object definitions and lifecycle explanation
data/raw/                       Dirty synthetic input CSVs
data/processed/                 Clean normalized CSVs and analytics exports
data/powerbi/                   Power BI measure guide placeholder and exports
reports/                        Build summary and data-quality report
docs/                           Consulting deliverables and user documentation
tests/                          Pytest coverage for pipeline, KPIs, scoring, automations
```

## Verified demo outputs

After running `python scripts/build_demo.py`, the project creates:

- `data/psp_flow_crm.db`
- `reports/data_quality_report.csv`
- `data/processed/customer_health_scores.csv`
- `data/processed/sales_funnel.csv`
- `reports/build_summary.md`

## CRM integration status

The project includes a real HubSpot HTTP connector for authenticated, read-only CRM snapshots. It supports pagination, retries, association retrieval, a separate live-snapshot SQLite database, and CSV exports. Live writes are blocked by default; guarded demo upserts require explicit local configuration.

A labelled synthetic scenario was also verified in the real HubSpot portal **PSP Logistics BD Ltd.**: one company, one contact, one deal, and two tasks were created and associated. See `docs/LIVE_HUBSPOT_VERIFICATION.md`.

## Portfolio case-study headline

Built a reproducible CRM and Customer Success Intelligence Platform for a synthetic logistics-automation SaaS, combining CRM data modelling, Python/SQL ETL, revenue analytics, rule-based customer health scoring, workflow automation, data-quality monitoring, and rule-based account briefings.


## Version 2: real HubSpot HTTP connector
The initial ZIP contained a no-op HubSpot skeleton. This upgrade implements real authenticated REST requests, paginated object reads, association retrieval, retries, a separate SQLite live snapshot, CSV exports, and a live-data viewer. It is a tested integration implementation with real HubSpot portal verification for labelled synthetic CRM records. The default public dashboard still uses synthetic data; token-based local sync must be configured by the user locally.

See [HubSpot integration and setup](docs/HUBSPOT_INTEGRATION.md) for credentials, scopes, commands, safety, and the verification checklist. The default dashboard and all public sample data remain synthetic. The ChatGPT HubSpot connection is not the same as a token supplied to this local application.

```bash
python scripts/hubspot_cli.py check
python scripts/hubspot_cli.py sync
python scripts/hubspot_cli.py export
```

The first command requires a locally configured token. No command writes to HubSpot. The optional read-only snapshot is separate from the original reproducible demo.


## Reviewer-ready commands

```bash
python scripts/build_demo.py
python scripts/load_verified_snapshot.py
pytest -q
streamlit run app.py
```

In the app sidebar, choose either **Synthetic demo** or **Live HubSpot snapshot**. The included snapshot is a verified synthetic scenario; for a fresh read-only sync, configure `HUBSPOT_PRIVATE_APP_TOKEN` locally and run `python scripts/hubspot_cli.py sync`.

## CV / LinkedIn copy

See `docs/CV_LINKEDIN_GITHUB_COPY.md` for safe application-ready wording.
