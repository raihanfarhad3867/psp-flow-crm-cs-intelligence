# Executive presentation outline

## Slide 1 — Business problem
PSP Flow needs a credible CRM operating model that connects sales pipeline, onboarding, product usage, support, renewals, and customer-success actions in one management view.

## Slide 2 — Solution architecture
Synthetic CRM data → raw CSV → validation → normalized SQLite database → KPI and health-score model → Streamlit dashboard → automation log and account briefing.

## Slide 3 — CRM system design
Core objects: company, contact, lead, deal, activity, subscription, onboarding, usage event, support ticket, task, customer-success activity, owner.

## Slide 4 — Revenue operations insights
The platform calculates funnel counts, conversion, win rate, weighted pipeline, response time, MRR, ARR, GRR, NRR, churned MRR, expansion MRR, and renewal calendar.

## Slide 5 — Customer success intelligence
A rule-based health score combines usage trend, onboarding progress, open support issues, and renewal timing to classify accounts as Healthy, Needs Attention, or At Risk.

## Slide 6 — Automations
Lead routing creates follow-up tasks; won subscriptions trigger onboarding tasks; at-risk health signals create customer-success review tasks.

## Slide 7 — Governance and adoption
Metric definitions, lifecycle rules, source picklists, duplicate checks, and human review of AI suggestions reduce reporting confusion and adoption risk.

## Slide 8 — Recommendation
Use the project as a portfolio demo and extend it with a real HubSpot sandbox integration, Power BI PBIX build, and optional dbt-style transformation layer.
