# CV-ready evidence

Use only after you have run the demo locally and can show the repository.

## CV bullets
- Built a reproducible CRM and Customer Success Intelligence Platform for a synthetic logistics-automation SaaS, designing normalized CRM objects for companies, contacts, leads, deals, subscriptions, onboarding, usage, support tickets and customer-success activities.
- Developed Python/SQL data pipelines with synthetic CRM data generation, SQLite schema constraints, data-quality checks, revenue KPI calculations, customer-health scoring and workflow automation logs.
- Created a Streamlit demo dashboard and AI-assisted account briefing feature to surface pipeline performance, MRR/ARR, retention metrics, onboarding progress, at-risk accounts and suggested customer-success actions.

## Interview explanation
I built this project to demonstrate the full CRM lifecycle rather than only a dashboard. I started with a B2B logistics-automation context, designed the CRM objects and lifecycle stages, generated realistic synthetic data, loaded it into a normalized SQL database, and created analytics and workflow logic on top. The strongest part is that the project connects Sales, RevOps, and Customer Success: a lead becomes a deal, a won deal becomes a subscription and onboarding plan, usage and support influence the health score, and at-risk customers create follow-up tasks. I kept the CRM integration safe by using a local adapter by default and documenting how HubSpot could be connected through environment variables.
