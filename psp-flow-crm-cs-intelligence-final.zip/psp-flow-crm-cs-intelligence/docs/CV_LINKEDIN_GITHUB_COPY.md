# CV, GitHub, and LinkedIn copy

## CV bullet

**PSP Flow — CRM & Customer Success Intelligence Platform**  
Built a Python, SQL, Streamlit, SQLite, and HubSpot CRM portfolio project for a synthetic B2B logistics-automation use case, covering CRM object design, ETL, data-quality checks, sales-pipeline KPIs, customer-health scoring, workflow tasks, and account briefings. Validated real HubSpot CRM record creation and associations using a labelled synthetic test scenario.

## Strong CV project description

Designed and built a reproducible CRM analytics platform for a synthetic logistics SaaS business using Python, SQL, SQLite, Streamlit, and HubSpot. Created normalized CRM data models for companies, contacts, deals, tasks, onboarding, usage, and support tickets; implemented revenue-operations KPIs, customer-health scoring, data-quality monitoring, and workflow automation. Verified real HubSpot CRM operations by creating and associating synthetic company, contact, deal, and task records in a test portal.

## LinkedIn post draft

I recently built **PSP Flow — a CRM & Customer Success Intelligence Platform** as a portfolio project to strengthen my work in CRM analytics, revenue operations, customer success, and business systems.

The project combines Python and SQL data pipelines, Streamlit dashboarding, CRM data modeling, sales-pipeline and customer-success KPIs, customer-health scoring, workflow task automation, data-quality monitoring, and a real HubSpot test scenario using clearly labelled synthetic records.

What I wanted to demonstrate was not just dashboard building, but the full business workflow: how CRM data moves from records into decisions, how sales and customer-success teams can prioritize accounts, and how data quality affects operational trust.

The project uses only synthetic demo data and is designed as a reproducible portfolio case study.

## Safe claim boundaries

Safe to claim:

- Built a CRM analytics and customer-success intelligence platform prototype.
- Designed CRM data models and lifecycle logic.
- Implemented data-quality checks, KPIs, health scoring, workflow tasks, and account briefings.
- Implemented a HubSpot HTTP connector for read-only snapshots and guarded demo writes.
- Verified real HubSpot CRM object creation and associations using synthetic demo records.

Do not claim:

- Production deployment.
- Real customer data.
- Real revenue impact.
- Full enterprise-grade two-way HubSpot synchronization.
- Salesforce implementation.
