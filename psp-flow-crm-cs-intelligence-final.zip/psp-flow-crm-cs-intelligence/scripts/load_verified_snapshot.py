"""Load the included HubSpot verification snapshot into the live-snapshot DB.

This does not contact HubSpot and does not write to HubSpot. It lets reviewers see
which synthetic records were verified in the real portal when they run the app
without a private app token.
"""
from __future__ import annotations

from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from psp_crm.hubspot_sync import connect, init, export, _now

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / "data" / "hubspot_verified_snapshot" / "verified_demo_records.json"
DB_PATH = ROOT / "data" / "hubspot_live.db"


def main() -> None:
    payload = json.loads(SNAPSHOT.read_text(encoding="utf-8"))
    if DB_PATH.exists():
        DB_PATH.unlink()
    with connect(DB_PATH) as conn:
        init(conn)
        for record in payload["records"]:
            conn.execute(
                """
                INSERT INTO crm_records(object_type, hubspot_id, properties_json, created_at, updated_at, last_seen_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    record["object_type"],
                    str(record["hubspot_id"]),
                    json.dumps(record.get("properties", {}), sort_keys=True),
                    record.get("created_at"),
                    record.get("updated_at"),
                    payload["verified_at"],
                ),
            )
        for edge in payload["associations"]:
            conn.execute(
                """
                INSERT INTO crm_associations(from_type, from_id, to_type, to_id, association_types_json)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    edge["from_type"],
                    str(edge["from_id"]),
                    edge["to_type"],
                    str(edge["to_id"]),
                    json.dumps(edge.get("association_types", []), sort_keys=True),
                ),
            )
        counts = {}
        for row in conn.execute("SELECT object_type, COUNT(*) FROM crm_records GROUP BY object_type"):
            counts[row[0]] = row[1]
        conn.execute(
            "INSERT INTO sync_runs(started_at, finished_at, status, counts_json, error) VALUES (?, ?, ?, ?, ?)",
            (_now(), _now(), "verified_snapshot_loaded", json.dumps(counts, sort_keys=True), None),
        )
        conn.commit()
    exports = export(DB_PATH, ROOT / "data" / "hubspot_exports")
    print(json.dumps({"database": str(DB_PATH), "counts": counts, "exports": exports}, indent=2))


if __name__ == "__main__":
    main()
